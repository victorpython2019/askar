import sqlite3 as sqlMaria 

#sqlite3 will collect the data and then store it

con = sqlMaria.connect("data.db")
dataInput = con.cursor()
dataInput.execute("CREATE TABLE `searchResults`(`link_name` text not null, `link_url` text not null, `link_descrip` text not null)")

